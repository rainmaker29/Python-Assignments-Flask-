import random
def generate_otp():
    return random.randint(100,10000)

my_gmail_password = ""