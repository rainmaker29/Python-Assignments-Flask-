list1 = ["Hello ", "take "]
list2 = ["Dear", "Sir"]
