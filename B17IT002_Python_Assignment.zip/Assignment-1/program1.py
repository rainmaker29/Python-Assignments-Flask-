l = [2,3,4,5,6,7]
print(list(map(lambda x:x**2,l)))
